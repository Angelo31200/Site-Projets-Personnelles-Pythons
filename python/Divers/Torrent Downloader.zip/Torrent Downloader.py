
from urllib.request import urlopen as uOpen
from qbittorrent import Client
import urllib.parse
import bs4 , requests , time , socket , os , sys
from requests import Session
from bs4 import BeautifulSoup as bSoup 
import xml , webbrowser
from xml import etree
from xml.etree import ElementTree
from pathlib import Path
from colorama import Fore , init
init()
os.system('cls')

#Qbitorrent
qb = Client('your ip adress')

qb.login('your_id', 'your_pass (default = adminadmin)')


lG = Fore.LIGHTGREEN_EX     # Colours
lY = Fore.LIGHTYELLOW_EX
lR = Fore.LIGHTRED_EX
cyan = Fore.CYAN
lC = Fore.LIGHTCYAN_EX
lB = Fore.LIGHTBLUE_EX

def slowprint(str):            # Slow print function
   for c in str :
     sys.stdout.write(c)
     sys.stdout.flush()
     time.sleep(0.4)

def rem_tags (st) :         # Removing html tag function

    return ''.join(xml.etree.ElementTree.fromstring(str(st)).itertext())

banner = """
▀█▀ █▀█ █▀█ █▀█ █▀▀ █▄░█ ▀█▀   █▀ █▀▀ ▄▀█ █▀█ █▀▀ █░█
░█░ █▄█ █▀▄ █▀▄ ██▄ █░▀█ ░█░   ▄█ ██▄ █▀█ █▀▄ █▄▄ █▀█"""
tagline = """
  [+] Tool by Upsilon      [+] oxtorrent.mx
-----------------------------------------------------"""

try:
    print(cyan + banner)
    print(lC + tagline)

    phrase = input("\nCherchez un Torrent : ")

    url ="https://www.oxtorrent.mx/recherche/" + phrase
    response = requests.get(url)

    if response.status_code == 200 :          
        
        redir_url = url # res.url                 # Getting the redirected url
        print("\nRecherche",end="")
        time.sleep(0.5)
        slowprint("....")                #print dots slowly

        headers = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36 OPR/70.0.3728.95"
        }
        time.sleep(0.5)
        os.system('cls')
        print(cyan + banner)
        print(lC + tagline)
        print(lC + f"\nCherche des résultats pour : \"{phrase}\" : \n")
        resps = requests.get(redir_url , headers=headers)      # Get request to get html code
        
        if resps.status_code == 200 :
            
            link_list = []
            t_no = 0
            #print(resps.text)
            #uClient = uOpen(redir_url)
            page_html = resps.text #uClient.read()                     # Setting response text as page_html
            #uClient.close()
            page_soup = bSoup(page_html,"html.parser")
            #print(page_soup)

            names = page_soup.find_all("div",{"class":"maxi"})         # Finding elements
            sizes = page_soup.find_all("td",{"align":"left", "width" : "11%"})
            
            if len(names) == 0 :                                        # checking if theres no torrents found  
                os.system('cls')
                print(cyan + banner)
                print(lC + tagline)
                print(lR + f"Pas de résultat pour : \"{phrase}\" ")
                time.sleep(4)
                exit()

            for i in range(len(names)) :
                nameN = rem_tags(names[i])                 # Removing Html tags and assign to new variable
                sizeN = rem_tags(sizes[i])
                links = names[i].find_all("a")
                link = str(links[0])
                link__splitted = link.split(" ")
                link__splitted = link__splitted[1]
                link = link__splitted[+6:-1]
                
                while True :                  # removing useless tag inside torrent size
                    if sizeN[-1] == "B" : 
                        break
                    sizeN = sizeN[:-1]
                t_no += 1
                linkN = "https://oxtorrent.mx" + link   # joining to make full url
                link_list.append(linkN)
                
                print(lC +"\n[",t_no,"] ",end="")       # Printing torrent list (for search phrase)
                print(lY + "",nameN)
                print("Size :",sizeN)
                time.sleep(0.3)
            
            print(lC + "")
            
            try:
                #print(lC +"\nTorrent Link :\n",lY + link_list[int(choice)-1])
                choice = input("Entrez le numéro d'un des torrents >>> ")                          # Input torrent number 
                Torr_link = link_list[int(choice)-1]
            except Exception as e2:
                print(lR + "Error",e2)    
                print("Entrez un numéro affiché !")                       # Error Handling

            resp3 = requests.get(Torr_link)    # Get request to get html data of selected torrent
            Down_links = []
            Down_sites = []

            page_html2 = resp3.text 
            page_soup2 = bSoup(page_html2,"html.parser")
            dropdown = page_soup2.find("div",{"class":"btn-magnet"})  #Getting download dropdown elements
            
            downsite_names = dropdown.find_all("a")
            
            for b in range(len(downsite_names)) :
                if b != 0 :
                    #print(rem_tags(downsite_names[b]))
                    Down_sites.append(rem_tags(downsite_names[b])) #append downloading site names to a list ex- itorrents 

            for a in dropdown.find_all('a', href=True):
                
                if a['href'] != "#" and a['href'] != "" :
                    #print("\n",a['href'])
                    Down_links.append(a['href'])    #append download links to a list                              # Download direct method (.torrent)  
            
            magnet_link = str(Down_links[0])
            session = Session()
            session.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
            save_path = ""

            os.system('cls')
            print(cyan + banner)
            print(lC + tagline)

            print("Le média téléchargé est : ")
            print(lC + "\n[1] "+lY+"Un Film \n\n"+lC+"[2]"+lY+" Une Série")
            choice2 = int(input(lC+"\n>>> "))

            if choice2 == 1:
                save_path += "/Films"

            else:
                os.system('cls')
                print(cyan + banner)
                print(lC + tagline)
                folder = []
                n = 1
                save_path += "/Series"
                save = "//NAS-SERVER/Series"
                for file in os.listdir(save):
                    d = os.path.join(save, file)
                    if os.path.isdir(d):
                        d = d.split("\\")
                        folder.append(d[-1])
                print()
                print("Choisissez un dossier ou créé s'en un : ")
                print()
                for x in folder:
                    print(lC + f"[{n}]"+lY+f" {x}")
                    print()
                    n+=1

                print(lC + f"[{n}] {lY} Créer un dossier")
                print()

                choice3 = int(input(lC+">>> "))
                print()

                if choice3 == n:
                    os.system('cls')
                    print(cyan + banner)
                    print(lC + tagline)
                    print()
                    print("Comment s'appelle la Serie ? ")
                    name_serie = input(">>> ")

                    newdir = f"{save_path}/{name_serie}"
                    if not os.path.isdir(newdir):
                        os.makedirs(newdir)

                    save_path = newdir
                
                else:
                    save_path+= f"/{folder[choice3-1]}"
            os.system('cls')
            print(cyan + banner)
            print(lC + tagline)
            print()
            qb.download_from_link(magnet_link, savepath = save_path)
            print(lG + "Téléchargement en cours", end = "")
            slowprint("....")
                
        else:                                                      
            print(lR + "Mauvaise redirection",resps.status_code)   # If Request error occrs these are printed

except Exception as e :
    print(lR + "Quelque chose s'est mal passé :/\n",e)

input("\nExit >")
