from random import*
import time

def saut_ligne(d):
    a = "\n" * d
    return print(a)

fichier = open("couleur.txt", 'r', encoding='utf-8')
fichier = fichier.read().splitlines()
tab_couleur = []
tab_couleur_réponse = []
tab_réponse = []
for x in fichier:
    tab_couleur.append(x)

d= True
niveau = 0

while True:
    niveau += 1
    random = randint(0,len(tab_couleur)-1)
    tab_couleur_réponse.append(tab_couleur[random])

    for x in tab_couleur_réponse:
        print(x)
        time.sleep(1)
        saut_ligne(150)

    print(tab_couleur)
    tab_réponse=[]
    rps = input(">>> Entrez la suite de couleurs qui vien d'être affichiée <<< ")

    if len(rps) > 1:

        rps = rps.split(" ")

    for x in rps:
        tab_réponse.append(x)

    print(tab_réponse)
    print(tab_couleur_réponse)

    d = 0

    for x in tab_couleur_réponse:
        if tab_réponse[d] != x:
            print("Mauvaise réponse !")
            print(f"Vous avez atteint le niveau {niveau}")
            exit()
        d += 1

    print("Bravo !")
    saut_ligne(150)