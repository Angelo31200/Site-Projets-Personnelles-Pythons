import requests
from tqdm import tqdm
import shutil
import os
import bs4 , requests , time , socket , os , sys
import xml , webbrowser
from pathlib import Path
from xml import etree
from xml.etree import ElementTree
from tqdm import tqdm
from bs4 import BeautifulSoup as bSoup
from colorama import Fore , init
init()
os.system('cls')

def slowprint(str):            # Slow print function
   for c in str :
     sys.stdout.write(c)
     sys.stdout.flush()
     time.sleep(0.4)

def rem_tags (st) :         # Removing html tag function

    return ''.join(xml.etree.ElementTree.fromstring(str(st)).itertext())

banner = """
   _____                                ________                      .__                    .___            
  /     \ _____    ____    _________    \______ \   ______  _  ______ |  |   _________     __| _/___________ 
 /  \ /  \\\\__  \  /    \  / ___\__  \    |    |  \ /  _ \ \/ \/ /    \|  |  /  _ \__  \   / __ |/ __ \_  __ \\
/    Y    \/ __ \|   |  \/ /_/  > __ \_  |    `   (  <_> )     /   |  \  |_(  <_> ) __ \_/ /_/ \  ___/|  | \/
\____|__  (____  /___|  /\___  (____  / /_______  /\____/ \/\_/|___|  /____/\____(____  /\____ |\___  >__|   
        \/     \/     \//_____/     \/          \/                  \/                \/      \/    \/       
"""
tag_line = """
            [+] Tool by Upsilon                                                     [+] sushiscan.net
------------------------------------------------------------------------------------------------------------------"""

lG = Fore.LIGHTGREEN_EX     # Colours
lY = Fore.LIGHTYELLOW_EX
lR = Fore.LIGHTRED_EX
cyan = Fore.CYAN
lC = Fore.LIGHTCYAN_EX
lB = Fore.LIGHTBLUE_EX

book_type = ""

headers = {
            "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0"
        }

cookies =  {"cf_clearance" : "U5bOEtQ_C.ukcgewc0N9RNnVN.cNAg3m36flt7D_7yM-1694902278-0-1-b9ec3c9a.b6d596d.4081db71-160.2.1694902278"}

print(lR + banner)
print(lY + tag_line)

phrase = input(lY + "\nCherchez un Manga : ")
phrase = phrase.replace(' ',"+")
url ="https://sushiscan.net/?s=" + phrase
response = requests.get(url, headers=headers, cookies=cookies)
if response.status_code == 200 :
    
    redir_url = url
    print("\nRecherche",end="")
    slowprint("....")

    time.sleep(0.5)
    os.system('cls')
    print(lR + banner)
    print(lY + tag_line)

    print(lC + f"\nCherche des résultats pour : \"{phrase}\" : \n") 
    
    resps = requests.get(redir_url , headers=headers, cookies=cookies)
    if resps.status_code == 200 :
        link_list = []
        name_list = []
        t_no = 0
        page_html = resps.text
        page_soup = bSoup(page_html,"html.parser")
        title_list = page_soup.find_all("a", title = True)
        title_list.pop(0)

        for x in title_list:
            link = str(x).split("\n")
            link_href = link[0].split(" ")
            link_list.append(link_href[1][+6:-1])
    
        for y in title_list:
           title = str(y).split("\"")
           name_list.append(title[3])
        
        n = 0

        for x in name_list:
           print(lC + f"[{n+1}]", end=" ")
           print(lY + f"{x}")
           print()
           time.sleep(0.3)
           n+=1

        choice2 = int(input("Entrez le numéro d'un des mangas >>> "))

        redir_url = link_list[choice2-1]
        name_bis = name_list[choice2-1]
        rps = requests.get(redir_url , headers=headers, cookies = cookies)

        if rps.status_code == 200:
            link_list2 = []
            name_list2 = []
            page_html = rps.text
            page_soup2 = bSoup(page_html,"html.parser")
            os.system('cls')
            print(lR + banner)
            print(lY + tag_line)

            volume = page_soup2.find_all("div",{"id" : "chapterlist"})
            volume_splitted = str(volume).split("<li")
            volume_splitted.pop(0)
            o = 0
            for x in volume_splitted :
                link = str(x).split("\n")
                name = link[0].split("data-num=")
                name = name[1][+1:-2]

                link = link[3][+9:-2]
                
                name_list2.append(name)
                link_list2.append(link)

            o = len(link_list2)
            for a in range(1,len(link_list2)+1):
               o-=1
               print(lC + f"[{a}]", end = "")
               print(lY + f"{name_list2[o]}")
               print()
               time.sleep(0.1)

            all_nb = []
            choice3 = input(f"Entrez le numéro du {book_type}>>> ")
            choice3_splitted = choice3.split(" ")
            if len(choice3_splitted) == 2:
                for x in range(int(choice3_splitted[0]),int(choice3_splitted[1])+1):
                    all_nb.append(x)

            else:
                all_nb.append(choice3)
            
            test = 0
            for s in all_nb:
                o = len(link_list2)
                real_choice = (o - (int(s)-1))-1

                redir_url = link_list2[real_choice]
                num_serie = int(name_list2[real_choice].split(" ")[1])
                book_type = name_list2[real_choice].split(" ")[0]+ " "
                if book_type == "Chapitre ":
                    i = 1

                else:
                    i = 0


                if num_serie < 10:
                    num_serie = "0"*(2+i) + str(num_serie)

                elif num_serie >= 10 and num_serie < 100:
                    num_serie = "0"* (1+i) + str(num_serie)

                elif num_serie >= 100 and num_serie < 1000:
                    num_serie = "0"*i + str(num_serie)

                else :
                    num_serie = str(num_serie)

                reps = requests.get(redir_url , headers=headers, cookies=cookies)

                if reps.status_code == 200:
                    all_pages_links = []
                    folder = []
                    n = 1
                    page_html = reps.text
                    page_soup3 = bSoup(page_html,"html.parser")
                    os.system('cls')
                    print(lR + banner)
                    print(lY + tag_line)
                    link = page_soup3.find_all("img",src = True)
                    link = link[+2:-8]
                    for x in link:
                        all_pages_links.append(str(x)[+27:-3])
                    
                    save_path = "./Mangas/"
                    if test == 0:
                        for file in os.listdir(save_path):
                            d = os.path.join(save_path, file)
                            if os.path.isdir(d):
                                d = d.split("\\")
                                folder.append(d[-1])

                        print("Choisissez un dossier ou créé s'en un : ")
                        for x in folder:
                            print(lC + f"[{n}]"+lY+f" {x}")
                            n+=1

                        print(lC + f"[{n}] {lY} Créer un dossier")

                        choice3 = int(input(lC+">>> "))
                        test = 1

                    print(lY)

                    if choice3 == n or test == 1:
                        name_serie = name_bis
                    
                    else:
                        name_serie = folder[choice3-1].split("/")[-1]

                    newdir = f"./Mangas/{name_serie}/{book_type}{num_serie}"
                    if not os.path.isdir(f"./Mangas/{name_serie}"):
                        os.makedirs(newdir)
                        os.makedirs(f"./Mangas/{name_serie}/Zipped")

                    elif not os.path.isdir(newdir):
                        os.makedirs(newdir)

                    save_path = newdir

                    path = save_path
                    os.system('cls')
                    print(lR + banner)
                    print(lY + tag_line)
                    print(lG)
                    
                    for link in tqdm(all_pages_links):
                        fichier = path +"/"+link.split("/")[-1]
                        r = requests.get(link,stream =True, headers = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/116.0"}, cookies=cookies)
                        r.raw.decode_content = True
                        with open(fichier, 'wb') as f:
                            shutil.copyfileobj(r.raw, f)
                    print()
                    print(lG + "Téléchargé avec succès !!!")
                    print()
                    print(lY + "Compression : ", end="")
                    shutil.make_archive(f"./Mangas/{name_serie}/Zipped/{book_type}{num_serie}",
                                'zip',
                                f"./Mangas/{name_serie}",
                                f"{book_type}{num_serie}")
                    my_file = Path(f"./Mangas/{name_serie}/Zipped/{book_type}{num_serie}.zip")
                    my_file.rename(my_file.with_suffix('.cbz'))
                    print(lG + "OK")
                    print()

                    if not os.path.isdir(f"//NAS-SERVER/Livres/Mangas/{name_serie}"):
                        os.makedirs(f"//NAS-SERVER/Livres/Mangas/{name_serie}")

                    print(lY + "Déplacement : ", end="")    
                    shutil.move(f"./Mangas/{name_serie}/Zipped/{book_type}{num_serie}.cbz",f"//NAS-SERVER/Livres/Mangas/{name_serie}/{book_type}{num_serie}.cbz")
                    print(lG + "OK")
                    shutil.rmtree(path)
else :
    print(lR + "Problème dans la recherche !!!!")