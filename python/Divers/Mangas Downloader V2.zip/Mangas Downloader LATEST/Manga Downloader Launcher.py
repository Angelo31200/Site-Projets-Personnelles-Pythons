import os
from pathlib import Path
import shutil
import tkinter as tk
from tkinter import ttk, Toplevel, filedialog
import requests
from bs4 import BeautifulSoup as bSoup
import threading



# Variables globales pour les headers et cookies
file_useragent = open("./DBtxt/useragent.txt", "r")
file_cookie = open("./DBtxt/cookie.txt", "r")
file_path = open("./DBtxt/path.txt","r")
cookie = file_cookie.readline().strip()
useragent = file_useragent.readline().strip()
path = file_path.readline().strip()

# Variables globales pour les headers, cookies et titre du manga
download_path = path
manga_title = ""  # Variable globale pour le titre du manga

headers = {
    "User-Agent": useragent
}

cookies = {
    "cf_clearance": cookie
}


dictNameMangaLink = {}
mangaName = ""

nameList2 = []
linkList2 = []

def download_in_background():
    thread = threading.Thread(target=download)
    thread.start()


def open_settings():
    settings_window = Toplevel(root)
    settings_window.title("Paramètres")

    tk.Label(settings_window, text="User-Agent:").pack(pady=5)
    useragent_entry = tk.Entry(settings_window, width=50)
    useragent_entry.pack(pady=5)
    useragent_entry.insert(0, useragent)

    tk.Label(settings_window, text="Cookie:").pack(pady=5)
    cookie_entry = tk.Entry(settings_window, width=50)
    cookie_entry.pack(pady=5)
    cookie_entry.insert(0, cookie)

    tk.Label(settings_window, text="Répertoire de Déplacement:").pack(pady=5)
    path_entry = tk.Entry(settings_window, width=50)
    path_entry.pack(pady=5)
    path_entry.insert(0, download_path)

    def browse_directory():
        directory = filedialog.askdirectory()
        if directory:
            path_entry.delete(0, tk.END)
            path_entry.insert(0, directory)

    tk.Button(settings_window, text="Parcourir...", command=browse_directory).pack(pady=5)

    def save_settings():
        global useragent, cookie, download_path, headers, cookies
        useragent = useragent_entry.get()
        cookie = cookie_entry.get()
        download_path = path_entry.get()

        global file_cookie
        global file_useragent
        global file_path
        if len(cookie)!=0:
            file_cookie.close()
            file_cookie = open("./DBtxt/cookie.txt", "w+")
            file_cookie.writelines(cookie)

        if len(useragent)!=0:
            file_useragent.close()
            file_useragent = open("./DBtxt/useragent.txt", "w+")
            file_useragent.writelines(useragent)

        if len(download_path)!=0:
            file_path.close()
            file_path = open("./DBtxt/path.txt","w+")
            file_path.writelines(download_path)
            

        file_cookie.close()
        file_useragent.close()

        headers = {
            "User-Agent": useragent
        }

        cookies = {
            "cf_clearance": cookie
        }

        settings_window.destroy()

    tk.Button(settings_window, text="Sauvegarder", command=save_settings).pack(pady=20)


def resultResearch(research):
    url = "https://sushiscan.net/?s=" + research
    response = requests.get(url, headers=headers, cookies=cookies)
    if response.status_code == 200:
        page_html = response.text
        page_soup = bSoup(page_html, "html.parser")
        title_list = page_soup.find_all("div", class_='tt')
        new_title_list = del_balises(title_list)
        link_list = [str(page_soup.find("a", title=y)).split('"')[1] for y in new_title_list]
        return new_title_list, link_list
    return [], []

def del_balises(tab_titles: list) -> list:
    new_tab_titles = []
    for x in tab_titles:
        x = str(x)[+16:-6]
        splittedX = x.split('\t')
        new_tab_titles.append(splittedX[4])
    return new_tab_titles

# Fonction pour enregistrer la recherche
def search():
    name_list2 = []
    link_list2 = []
    mangaName = ""
    dictNameMangaLink = {}

    DownloadButton.pack_forget()

    search_query = entry.get()
    modified_query = search_query.replace(' ', '+')
    
    titles, links = resultResearch(modified_query)

    if len(search_query)!=0:
        result_label.config(text=f"Résultats pour la recherche: {search_query} ({len(links)})")
    display_results(titles, links)

# Fonction pour afficher les résultats avec des boutons radio
def display_results(titles, links):
    global selected_result
    selected_result = tk.StringVar(value="")

    for widget in results_frame.winfo_children():
        widget.destroy()  # Nettoyer le cadre des résultats précédents

    canvas = tk.Canvas(results_frame)
    scrollbar = tk.Scrollbar(results_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all   ")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    for title, link in zip(titles, links):
        dictNameMangaLink[link] = title
        radiobutton = tk.Radiobutton(scrollable_frame, text=title, variable=selected_result, value=link)
        radiobutton.pack(anchor='w')

    

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

# Fonction pour afficher les résultats des volumes avec des checkboxes
def display_resultsVolumes(titles, links):
    global selected_result
    global volume_vars

    volume_vars = {}
    result_label.config(text=f"Liste des Volumes / Chapitre pour {mangaName} ({len(titles)}) :")

    selected_result = tk.StringVar(value="")

    for widget in results_frame.winfo_children():
        widget.destroy()  # Nettoyer le cadre des résultats précédents

    canvas = tk.Canvas(results_frame)
    scrollbar = tk.Scrollbar(results_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    for title, link in zip(titles, links):
        var = tk.BooleanVar()
        checkbox = tk.Checkbutton(scrollable_frame, text=title, variable=var)
        checkbox.pack(anchor='w')
        volume_vars[link]={title : var}

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

def linkandnamelistempty():
    global linkList2
    global nameList2
    linkList2 = []
    nameList2 = []

# Fonction pour obtenir le résultat sélectionné
def get_selected_result():
    selected_link = selected_result.get()

    if (len(linkList2)!= 0) or  (len(nameList2)!= 0):
        linkandnamelistempty()

    global mangaName
    mangaName = dictNameMangaLink[selected_link]
    if selected_link:
        rps = requests.get(selected_link, headers=headers, cookies=cookies)
        if rps.status_code == 200:
            
            page_html = rps.text
            page_soup2 = bSoup(page_html, "html.parser")
            volume = page_soup2.find_all("div", {"id": "chapterlist"})
            links = volume[0].find_all("a")

            volume_splitted = str(volume).split("<li")
            volume_splitted.pop(0)

            for x in links:
                link = str(x).split('"')[1]
                linkList2.append(link)

            for x in volume_splitted:
                link = str(x).split("\n")
                name = link[0].split("data-num=")
                name = name[1][+1:-2].split('"')[0]
                nameList2.append(name)

            display_resultsVolumes(nameList2, linkList2)
            DownloadButton.pack(pady=10)

def special_char_del(str):
    special_car_list = ["<", ">",":", "/", " \\", "|", "?", "*" ,'"']
    new_name = ""
    for x in str:
        if x in special_car_list:
            new_name+="-"
        else:
            new_name+=x

    return new_name
    
def download(): 
    entry["state"] = "disabled"
    DownloadButton["state"] = "disabled"
    get_result_button["state"] = "disabled"
    search_button["state"] ="disabled"
    dictVolumesURL = {}
    for link, titleVar in volume_vars.items():
        for title, var in titleVar.items():
            if var.get():
                dictVolumesURL[title] = link
    
    test= 0
    for title, link in dictVolumesURL.items():
                redir_url = link
                num_serie = title.split(" ")[1]
                book_type = title.split(" ")[0]+ " "
                if book_type == "Chapitre ":
                    book_type = "Ch."
                    i = 1

                else:
                    i = 0

                reps = requests.get(redir_url , headers=headers, cookies=cookies)

                if reps.status_code == 200:
                    folder = []
                    n = 1
                    page_html = reps.text
                    page_soup3 = bSoup(page_html,"html.parser")
                    divWrapper = page_soup3.find("div", class_ = "wrapper").find_all("script")[1]
                    all_pages_links = AllPages(str(divWrapper))

                    save_path = download_path
                    if test == 0:
                        for file in os.listdir(save_path):
                            d = os.path.join(save_path, file)
                            if os.path.isdir(d):
                                d = d.split("\\")
                                folder.append(d[-1])
                    
                    print(mangaName)
                    name_serie = mangaName

                    newdir = f"./Mangas/{name_serie}/{book_type}{num_serie}"
                    if not os.path.isdir(f"./Mangas/{name_serie}"):
                        os.makedirs(newdir)
                        os.makedirs(f"./Mangas/{name_serie}/Zipped")

                    elif not os.path.isdir(newdir):
                        os.makedirs(newdir)

                    path = newdir

                    labelNameVolumeProgressBarTitle = tk.Label(text = f"{name_serie} {book_type} {num_serie}")
                    labelNameVolumeProgressBarTitle.pack(pady=10)
                    progress = ttk.Progressbar(root, orient = "horizontal", length = 300)
                    progress.pack(pady = 5)
                    progress["maximum"] = len(all_pages_links)
                    progress["value"] = 0
                    
                    for link in all_pages_links:
                        fichier = path +"/"+link.split("/")[-1]
                        r = requests.get(link,stream =True, headers = headers, cookies=cookies)
                        r.raw.decode_content = True
                        with open(fichier, 'wb') as f:
                            shutil.copyfileobj(r.raw, f)
                        progress["value"]+=1
                        root.update_idletasks()
                    shutil.make_archive(f"./Mangas/{name_serie}/Zipped/{book_type}{num_serie}",
                                'zip',
                                f"./Mangas/{name_serie}",
                                f"{book_type}{num_serie}")
                    my_file = Path(f"./Mangas/{name_serie}/Zipped/{book_type}{num_serie}.zip")
                    my_file.rename(my_file.with_suffix('.cbz'))
                    
                    if not os.path.isdir(f"{save_path}/{name_serie}"):
                        os.makedirs(f"{save_path}/{name_serie}")
 
                    shutil.move(f"./Mangas/{name_serie}/Zipped/{book_type}{num_serie}.cbz",f"{save_path}/{name_serie}/{name_serie} - {book_type}{num_serie}.cbz")
                    labelNameVolumeProgressBarTitle.pack_forget()
                    progress.pack_forget()

    shutil.rmtree(f"./Mangas/{name_serie}/", ignore_errors= True)
    entry["state"] = "normal"
    DownloadButton["state"] = "normal"
    get_result_button["state"] = "normal"
    search_button["state"] ="normal"



def AllPages(string : str) -> list:
    stringsplitted = string.split("[")[2].split("]")[0].split('","')
    finalLinksPages = []
    for x in stringsplitted:
        link = ""
        
        for y in x:
            if y != "\\":
                link+=y
                
        finalLinksPages.append(link)
    finalLinksPages[0] = finalLinksPages[0][+1:]
    finalLinksPages[-1] = finalLinksPages[-1][:-1]
    return finalLinksPages

# Ajout de l'icône des paramètres




# Créer la fenêtre principale
root = tk.Tk()
root.geometry("1280x720")
root.title("Manga Downloader")
root.iconbitmap("./images/logoMangaDownloader.ico")

settings_icon = tk.PhotoImage(file = "./images/settings.png")  # Assurez-vous d'avoir une image 'settings.png'
settings_button = tk.Button(root, image=settings_icon, command=open_settings, borderwidth=0)
settings_button.pack(side="top", anchor="ne", padx=10, pady=10)

logoCanvas = tk.PhotoImage(file = "./images/LogoCanvas.png")
labelLogo = tk.Label(root, image = logoCanvas)
labelLogo.pack(side="top", anchor="n", padx=10, pady=10)

# Créer un champ de saisie
entry = tk.Entry(root, width=50)
entry.pack(pady=20)

# Créer un bouton de recherche
search_button = tk.Button(root, text="Rechercher", command=search)
search_button.pack(pady=10)



# Créer un label pour afficher le résultat de la recherche
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

# Créer un cadre pour afficher les résultats avec des boutons radio
results_frame = tk.Frame(root)
results_frame.pack(pady=20)

# Créer un bouton pour obtenir le résultat sélectionné
get_result_button = tk.Button(root, text="Obtenir le résultat sélectionné", command=get_selected_result)
get_result_button.pack(pady=10)

# Remplacer l'ancienne ligne par celle-ci
DownloadButton = tk.Button(root, text="Download", command=download_in_background)



# Dictionnaire pour stocker les variables associées aux volumes
volume_vars = {}

# Variable pour stocker la sélection
selected_result = tk.StringVar()

# Lancer la boucle principale de l'application
root.mainloop()
