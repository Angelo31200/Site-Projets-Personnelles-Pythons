from random import*

def saut_ligne(n):
    a = "\n" * n
    return a

def verification(rep, tab):
    print(tab)

    if rep == tab:
        print(saut_ligne(2))
        print("Bonne réponse")
    
    else:
        print(saut_ligne(2))
        print("Perdu !! La bonne réponse était : ",tab)

    print(saut_ligne(2))

f = open("Français.txt", "r")
e = open("Espagnol.txt", "r")
f = f.read().splitlines()
e = e.read().splitlines()

mot_espagnol = []
mot_francais = []

for i in f:
    mot_francais.append(i)

for i in e:
    mot_espagnol.append(i)

print(e)
print(f)

print("##############################")
print("# 1 = français vers espagnol #")
print("# 2 = espagnol vers français #")
print("##############################")

print(saut_ligne(2))

chs = int(input(">>> Choississez un entraînement <<< : "))

print(saut_ligne(2))

if chs == 1:
    while True:
        rdm = randrange(len(mot_espagnol)-1)

        print("Le mot a traduire est : ", mot_francais[rdm])

        print(saut_ligne(2))

        rps = input("Entrez votre réponse : ")

        verification(rps, mot_espagnol[rdm])


if chs == 2:
    while True:
        rdm = randrange(len(mot_espagnol)-1)

        print("Le mot a traduire est : ", mot_espagnol[rdm])

        print(saut_ligne(2))

        rps = input("Entrez votre réponse : ")

        verification(rps, mot_francais[rdm])
