Taille_Pierre_Chabrier = 1.87
Tab = []
new_Tab = []

chs = input(">>> Qu'est ce que vous voulez faire ? (calculer/convertir) <<< ")

if chs == "calculer":
    Taille_obj = input(">>> Entrez la taille de l'objet (avec  unité) <<< ")

    Tab.append(Taille_obj.split(" "))

    for x in Tab[0]:
        new_Tab.append(x)

    if new_Tab[1] == 'M' or new_Tab[1] == 'm':
        resultat = round(float(new_Tab[0])/Taille_Pierre_Chabrier, 2)

    elif new_Tab[1] == 'cm' or new_Tab[1] == 'CM' or new_Tab[1] == 'cM' or new_Tab[1] == 'Cm':
        Taille_m = float(new_Tab[0]) * 10 ** -2
        resultat = round(Taille_m / Taille_Pierre_Chabrier, 2)

    elif new_Tab[1] == 'km' or new_Tab[1] == 'KM' or new_Tab[1] == 'kM' or new_Tab[1] == 'Km':
        Taille_m = float(new_Tab[0]) * 10 ** 3
        resultat = round(Taille_m / Taille_Pierre_Chabrier, 2)

    print(Taille_obj,"fait",resultat,"Pierre Chabrier")

elif chs == "convertir":
    Taille_en_Pierre_Chabrier = float(input(">>> Entrez la taille en Pierre-Chabrier <<< "))

    calcul = Taille_en_Pierre_Chabrier * Taille_Pierre_Chabrier

    print(Taille_en_Pierre_Chabrier, "Pierre Chabrier correspond à", calcul,"mètres")