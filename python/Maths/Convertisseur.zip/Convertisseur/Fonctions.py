from Tableaux import*

def créer_tableau(fichier):
    fichier = fichier.read().splitlines()
    tab=[]
    for x in fichier:
        tab.append(x)

    return tab

def séléction(tab,n):
    if n == 0:
        a = "L'unité est une unité \n"

    elif n>=1:
        a = "Choississez l'unité dans laquelle vous allez convertir votre séléction\n"
    print(a + "-"*len(a))

    for i, unité in enumerate(tab):
        print(i+1 , "=",unité)

    print("-"*len(a))

    chs = int(input(">>> Entrez le chiffre correspondant <<< "))
    return chs

def entrée_utilisateur():
    tab = []
    while True:
        entrée = input(">>> Entrez votre valeur avec l'unité <<< ")

        entrée = entrée.split(' ')
        for x in entrée:
            tab.append(x)

        if len(tab) != 2:
            print("ATTENTION !!! Regardez que vous ayez bien mis l'unité")
            tab = []
            input()

        else:
            break

    for x in tab[0]:
        if x == ',':
            tab[0] = tab[0].replace(",", ".")

    flotant = float(tab[0])
    tab[0] = flotant

    return tab

def num_tab_unités(tab_unité,unité_user):
    num_unité_user = tab_unité.index(unité_user)

    return num_unité_user

def convert_base(a, dif_index, entrée, tab,index_unité_user):

    abs_dif_index = abs(dif_index)

    if dif_index>0:
        multiplicateur = int("1" + a * abs_dif_index)
        convert = entrée[0] * multiplicateur
        print(convert , tab[index_unité_user])

    else :
        multiplicateur = int("1" +a*abs_dif_index)
        convert = entrée[0] * 1/multiplicateur
        print(convert , tab[index_unité_user])

def before_convert_base(tab,a,n):
    entrée = entrée_utilisateur()
    index_unité_user = séléction(tab, n) - 1

    index_unité = num_tab_unités(tab, entrée[1])
    if n<2:
        dif_index = index_unité - index_unité_user

        convert_base(a, dif_index, entrée, tab, index_unité_user)

    else:
        convert_temp(entrée, index_unité_user, index_unité, tab)

def convert_temp(entrée,index_unité_user, index_unité, tab):
    if index_unité == 0 and index_unité_user == 1:
        convert = (entrée[0]*(9/5))+32


    elif index_unité == 1 and index_unité_user == 0:
        convert = (entrée[0]-32)*(5/9)

    elif index_unité == 0 and index_unité_user == 2:
        convert = entrée[0] + 273.15

    elif index_unité == 2 and index_unité_user == 0:
        convert = entrée[0] - 273.15

    elif index_unité == 1 and index_unité_user == 2:
        convert = (entrée[0]-32)*(5/9) + 273.15

    elif index_unité == 2 and index_unité_user == 1:
        convert = (entrée[0] - 273.15)*(9/5)+32

    print(round(convert,2), tab[index_unité_user])