from Tableaux import*
from Fonctions import*
n = 0
dif_index = 0
chs_unité = séléction(tab_unités,n)
n+=1
a = None


if chs_unité == 1:
    a = "00"
    tab = tab_aire

elif chs_unité == 2:
    a = "000"
    tab = tab_capacité

elif chs_unité == 3:
    a = "0"
    tab = tab_masse

elif chs_unité == 4:
    a = "0"
    tab = tab_mesure

elif chs_unité == 5 :
    a = "000"
    tab = tab_volume

elif chs_unité == 6:
    n+=1
    tab = tab_temperature

before_convert_base(tab, a, n)