from Fonctions import*
from math import *
tab_moy = []
tab_mat = []

n = 0
rps = "y"
while True:
    n+=1

    if n > 1:
        rps = input(">>> Voulez vous ajouter une moyenne <<< (y/n) ")

    if rps == "y":
        moyenne = moyenne_calc()

        matière = input(">>> Entrez la matère a laquelle correspond cette moyenne <<< ")

        tab_mat.append(matière)

        str_moyenne = str(round(moyenne,2))
        a = len(str_moyenne)
        b = len(matière)
        c = b - a

        if c%2!=0:
            c = c/2
            tab_moy.append(" "*ceil(c) + str_moyenne + " "*floor(c))

        else:
            c = int(c / 2)
            tab_moy.append(" " * c + str_moyenne + " " * c)

    elif rps == "n":
        break

print("Votre moyenne générale est de : ",round(moyenne_gen(tab_moy, tab_mat),2))