def moyenne_calc():
    tab_note = []
    tab_coef = []

    while True:
        note = input(">>> Entrez une note <<< ")
        n = -1
        for x in note:
            n+=1
            if x == ",":
                note[n]="."

        coef = input(">>> Entrez le coefficient de la note <<< ")

        if len(note)==0 or len(coef)==0:
            break

        coef = float(coef)
        note = float(note)*coef

        tab_note.append(note)
        tab_coef.append(coef)

    somme_note=0
    somme_coef=0
    y = -1
    for x in tab_note:
        y+=1
        somme_note+=x
        somme_coef+=tab_coef[y]

    moyenne = somme_note/somme_coef

    return moyenne

def moyenne_gen(tab_moy,tab_mat):
    print(tab_mat)
    print(tab_moy)

    somme_note = 0
    for x in tab_moy:
        somme_note+=float(x)

    moyenne_gen = somme_note/len(tab_mat)

    return moyenne_gen