from Fonction import*

print('#' * 28 + '\n# 1 = Suites Arithmétiques #\n# 2 = Suites Géométriques  #\n# 3 =        Sommes        #\n# 4 =   Calculer u de n    #\n' + '#' * 28)

saut_ligne(2)

chs = int(input ("Programme N° ")) 

saut_ligne(2)

if chs == 1:
    
    val_suite()

    result = seuil_arith(tab_val[0],tab_val[1],tab_val[2],tab_val[3])

if chs == 2:
    
    val_suite()

    result = seuil_geome(tab_val[0],tab_val[1],tab_val[2],tab_val[3])

if chs < 3:
    print("L'indice seuil de", tab_val[3], "est",result)

if chs == 3 :
    print('#' * 28 + '\n# 1 = Suites Arithmétiques #\n# 2 = Suites Géométriques  #\n' + '#' * 28)
    
    saut_ligne(2)


    nm_pgrm = int(input("Programme N°"))

    saut_ligne(2)

    if nm_pgrm == 1:
        val_somme()

        result_somme = round(((tab_val_somme[0]+tab_val_somme[1])*tab_val_somme[2])/2,2)

    if nm_pgrm == 2:
        val_somme_géomé()
        
        result_somme = round(tab_val_somme[1]*((1 - tab_val_somme[0]**tab_val_somme[3])/(1 - tab_val_somme[0])))

    saut_ligne(2)
    print("Somme = ", result_somme)

if chs == 4:
    print('#' * 28 + '\n# 1 = Suites Arithmétiques #\n# 2 = Suites Géométriques  #\n' + '#' * 28)
    
    saut_ligne(2)

    nm_pgrm = int(input("Programme N°"))

    tab_indices.append("n")
    tab_val.append("u")

    if nm_pgrm == 1:
        calc_suite_arithm()


    if nm_pgrm == 2:
        calc_suite_géo()
