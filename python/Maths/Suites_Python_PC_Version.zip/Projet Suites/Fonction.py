# Tableau de stockage des valeurs

tab_val = []
tab_val_somme = []
tab_indices = []

# Fonction pour le saut de ligne

def saut_ligne(n):
    a= "\n" * n
    return print(a)

# Valeurs Sommes Arithmétiques

def val_somme():
    p = float(input(" Premier terme : "))
    indice_p = int(input(" Indice du premier terme : "))
    d = float(input(" Dernier terme : "))
    indice_d = int(input(" Indice du dernier terme : "))
    nb_termes = indice_d-indice_p+1

    tab_val_somme.extend([p,d,nb_termes])

    return nb_termes

# Valeurs Sommes Géométrique

def val_somme_géomé():
    r = float(input(" Raison = "))
    p = float(input(" Premier terme : "))
    indice_p = int(input(" Indice du premier terme : "))
    d = float(input(" Dernier terme : "))
    indice_d = int(input(" Indice du dernier terme : "))
    nb_termes = indice_d-indice_p+1

    tab_val_somme.extend([r,p,d,nb_termes])

# Seuil Suite Arithmétique

def seuil_arith(u,n,r,s):
    
    if u<=s :
    
        while u<=s:
    
            n+=1
            u+=r

    else:
        while u>=s:
    
            n+=1
            u+=r

    
    return n

# Seuil Suite Géométrique

def seuil_geome(u,n,r,s):
    if u<=s :

        while u<=s:
    
            n += 1
            u *= r

    else:
        while u>=s:
    
            n += 1
            u *= r
    
    return n

# Valeurs Seuil Suites

def val_suite():
    u = float(input("u = "))
    n = int(input("n = "))
    r = float(input("Raison =  "))
    s = float(input("Seuil = "))

    tab_val.extend([u,n,r,s])

# Calcul u de n 
    
def calc_suite_arithm():
    
    r = float(input(" Raison = "))
    p = float(input(" Premier terme : "))
    indice_1 = int(input(" Indice du premier terme : "))
    indice_2 = int(input(" Indice du terme à calculer : "))

    for i in range (indice_1, indice_2+1):
        if len(str(i)) > 1:
            a = str(i) + " " * (len(str(p)) - (len(str(i))) - 2 )
        else :
            a = str(i) + " " * (len(str(p))-3)
        
        
        tab_indices.append(a)
        tab_val.append(p)
        p += r

    return print("",tab_indices,"\n",tab_val)

def calc_suite_géo():
    
    r = float(input(" Raison = "))
    p = float(input(" Premier terme : "))
    indice_1 = int(input(" Indice du premier terme : "))
    indice_2 = int(input(" Indice du terme à calculer : "))
    # Affichage du tableau
    for i in range (indice_1, indice_2+1):
        if len(str(i)) > 1:
            a = str(i) + " " * (len(str(p)) - (len(str(i))) - 2 )
        else :
            a = str(i) + " " * (len(str(p))-3)
        
        
        tab_indices.append(a)
        tab_val.append(p)
        p *= r

    return print("",tab_indices,"\n",tab_val)