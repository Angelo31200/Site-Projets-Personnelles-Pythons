def biscextile(année):


    if année%4 == 0 and année%100 !=0 or année%400 == 0:
        return True

    return False

liste_mois=[]
tab_date_jour=[]
tab_date_naissance=[]
num_mois_naissance = 0
num_mois_date = 0
n = -1
fichier = open("list_mois.txt", "r", encoding="utf-8")
fichier = fichier.read().splitlines()
for x in fichier:
    liste_mois.append(x)

nb_jour_max = [31,28,31,30,31,30,31,31,30,31,30,31]
nb_jour_max_bis = [31,29,31,30,31,30,31,31,30,31,30,31]

date_naissance = input(">>> Entrez votre date de naissance (jour/mois/année) <<< ")
backup_naissance = date_naissance
date_jour = input(">>> Entrez la date d'aujourd'hui (jour/mois/année) <<< ")
backup_jour = date_jour

date_naissance = date_naissance.split(" ")
date_jour = date_jour.split(" ")

if date_naissance[1][0].islower()==True:
    maj_char = date_naissance[1][0].upper()
    date_naissance[1]=date_naissance[1].replace(date_naissance[1][0],maj_char)

if date_jour[1][0].islower()==True:
    maj_char = date_jour[1][0].upper()
    date_jour[1]=date_jour[1].replace(date_jour[1][0],maj_char)

for x in date_naissance:
    tab_date_naissance.append(x)

for x in date_jour:
    tab_date_jour.append(x)

biscextile_naissance = biscextile(int(tab_date_naissance[2]))
biscextile_jour = biscextile(int(tab_date_jour[2]))

for x in liste_mois:
    n += 1
    if tab_date_naissance[1] == x:
        num_mois_naissance = n
        continue
n=-1
for x in liste_mois:
    n += 1
    if tab_date_jour[1] == x:
        num_mois_date = n
        continue

if int(tab_date_naissance[0]) > nb_jour_max[num_mois_naissance] and biscextile_naissance == False:
    print(">>> Date Impossible <<<")
    exit

elif int(tab_date_naissance[0]) > nb_jour_max_bis[num_mois_naissance] and biscextile_naissance == True:
    print(">>> Date Impossible <<<")
    exit

if int(tab_date_jour[0]) > nb_jour_max[num_mois_date] and biscextile_jour == False:
    print(">>> Date Impossible <<<")
    exit

elif int(tab_date_jour[0]) > nb_jour_max_bis[num_mois_date] and biscextile_jour == True:
    print(">>> Date Impossible <<<")
    exit

nb_années = int(tab_date_jour[2])- int(tab_date_naissance[2])

nb_mois = num_mois_date - num_mois_naissance

nb_jour = int(tab_date_jour[0])- int(tab_date_naissance[0])

if biscextile_naissance == True:

    if nb_jour<0:
        nb_jour = nb_jour_max_bis[num_mois_naissance] + nb_jour
        nb_mois -= 1

elif biscextile_naissance == False:
    if nb_jour<0:
        nb_jour = nb_jour_max[num_mois_naissance] + nb_jour
        nb_mois -= 1

if nb_mois < 0:
    nb_mois = 12 + nb_mois
    nb_années -= 1

if nb_jour > 1 and nb_années > 1:

    print("L'écart entre le", backup_naissance,"et le", backup_jour, "est de", nb_jour,"jours,",nb_mois, "mois et",nb_années,"années")

if nb_jour <= 1 and nb_années > 1:

    print("L'écart entre le", backup_naissance,"et le", backup_jour, "est de", nb_jour,"jour,",nb_mois, "mois et",nb_années,"années")

if nb_jour <= 1 and nb_années <= 1:

    print("L'écart entre le", backup_naissance,"et le", backup_jour, "est de", nb_jour,"jour,",nb_mois, "mois et",nb_années,"année")

if nb_jour > 1 and nb_années <= 1:

    print("L'écart entre le", backup_naissance,"et le", backup_jour, "est de", nb_jour,"jours,",nb_mois, "mois et",nb_années,"année")