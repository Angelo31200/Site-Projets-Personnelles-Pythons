from Def_Zodiaque import*

date = input(">>> Entrez une date de naissance (jour/mois) <<< ")
tab = []
tab_résult = []
nb = 0
tab.append(date.split(" "))
result = zodiaque(tab)
print(result)
tab_résult.append(result.split(" "))

signe = tab_résult[0][4]

rps_caract = input(">>> Voulez-vous connaître votre caractère ? (oui/non) <<< ")

if rps_caract == "oui":
    caractère = caractère(signe)
    print(caractère)

else:
    True
