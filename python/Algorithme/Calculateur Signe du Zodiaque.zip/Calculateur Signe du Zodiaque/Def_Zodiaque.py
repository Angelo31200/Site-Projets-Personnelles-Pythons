

def saut_ligne(n):
    f = " "*n
    return print(f)

def zodiaque(tab):
    v = ""
    if int(tab[0][0]) > 31:
        return print("Date Impossible")

    elif tab[0][1] == "Février" or tab[0][1] == "février" and tab[0][0] >= 29:
        return print("Date Impossible")

    if tab[0][1] == "Mars" or tab[0][1] == "mars" and tab[0][0] >= "21" or \
            tab[0][1] == "Avril" or tab[0][1] == "avril" and tab[0][0] <= "19":
        v = "Vous êtes du signe Bélier"

    elif tab[0][1] == "Avril" or tab[0][1] == "avril" and tab[0][0] >= "20" or \
            tab[0][1] == "Mai" or tab[0][1] == "mai" and tab[0][0] <= "20":
        v = "Vous êtes du signe Taureau"

    elif tab[0][1] == "Mai" or tab[0][1] == "mai" and tab[0][0] >= "21" or \
            tab[0][1] == "Juin" or tab[0][1] == "juin" and tab[0][0] <= "21":
        v = "Vous êtes du signe Gémeaux"


    elif tab[0][1] == "Juin" or tab[0][1] == "juin" and tab[0][0] >= "22" or \
            tab[0][1] == "Juillet" or tab[0][1] == "juillet" and tab[0][0] <= "22":
        v = "Vous êtes du signe Cancer"

    elif tab[0][1] == "Juillet" or tab[0][1] == "juillet" and tab[0][0] >= "23" or \
            tab[0][1] == "Août" or tab[0][1] == "août" and tab[0][0] <= "22":
        v = "Vous êtes du signe Lion"

    elif tab[0][1] == "Août" or tab[0][1] == "août" and tab[0][0] >= "23" or \
            tab[0][1] == "Septembre" or tab[0][1] == "septembre" and tab[0][0] <= "22":
        v = "Vous êtes du signe Vierge"

    elif tab[0][1] == "Septembre" or tab[0][1] == "septembre" and tab[0][0] >= "23" or \
            tab[0][1] == "Octobre" or tab[0][1] == "octobre" and tab[0][0] <= "23":
        v = "Vous êtes du signe Balance"

    elif tab[0][1] == "Octobre" or tab[0][1] == "octobre" and tab[0][0] >= "24" or \
            tab[0][1] == "Novembre" or tab[0][1] == "Novembre" and tab[0][0] <= "22":
        v = "Vous êtes du signe Scorpion"

    elif tab[0][1] == "Novembre" or tab[0][1] == "novembre" and tab[0][0] >= "23" or \
            tab[0][1] == "Décembre" or tab[0][1] == "décembre" and tab[0][0] <= "22":
        v = "Vous êtes du signe Sagittaire"

    elif tab[0][1] == "Décembre" or tab[0][1] == "décembre" and tab[0][0] >= "23" or \
            tab[0][1] == "Janvier" or tab[0][1] == "janvier" and tab[0][0] <= "20":
        v = "Vous êtes du signe Capricorne"

    elif tab[0][1] == "Janvier" or tab[0][1] == "janvier" and tab[0][0] >= "21" or \
            tab[0][1] == "Février" or tab[0][1] == "février" and tab[0][0] <= "19":
        v = "Vous êtes du signe Verseau"

    elif tab[0][1] == "Février" or tab[0][1] == "février" and tab[0][0] >= "20" or \
            tab[0][1] == "Mars" or tab[0][1] == "mars" and tab[0][0] <= "20":
        v = "Vous êtes du signe Poisson"

    return v

def caractère(signe):
    if signe == 'Bélier':
        fichier = open("Bélier.txt", "r", encoding='utf-8')

    elif signe == 'Taureau':
        fichier = open("Taureau.txt", "r", encoding='utf-8')

    elif signe == 'Gémeaux':
        fichier = open("Gémeaux.txt", "r", encoding='utf-8')

    elif signe == 'Cancer':
        fichier = open("Cancer.txt", "r", encoding='utf-8')

    elif signe == 'Lion':
        fichier = open("Lion.txt", "r", encoding='utf-8')

    elif signe == 'Vierge':
        fichier = open("Vierge.txt", "r", encoding='utf-8')

    elif signe == 'Balance':
        fichier = open("Balance.txt", "r", encoding='utf-8')

    elif signe == 'Scorpion':
        fichier = open("Scorpion.txt", "r", encoding='utf-8')

    elif signe == 'Sagittaire':
        fichier = open("Sagittaire.txt", "r", encoding='utf-8')

    elif signe == 'Capricorne':
        fichier = open("Capricorne.txt", "r", encoding='utf-8')

    elif signe == 'Verseau':
        fichier = open("Verseau.txt", "r", encoding='utf-8')

    elif signe == 'Poisson' :
        fichier = open("Poisson.txt", "r", encoding='utf-8')

    fichier = fichier.read()
    return fichier

